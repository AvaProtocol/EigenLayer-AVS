import { describe, beforeAll, test, expect } from "@jest/globals";
import { Client, TimeoutPresets } from "@avaprotocol/sdk-js";
import { getAddress, generateSignature } from "./utils";
import { getConfig } from "./envalid";

jest.setTimeout(30000);

const { avsEndpoint, walletPrivateKey, factoryAddress } = getConfig();

describe("SDK Timeout Configuration Tests", () => {
  let eoaAddress: string;
  let client: Client;

  beforeAll(async () => {
    eoaAddress = await getAddress(walletPrivateKey);
    client = new Client({
      endpoint: avsEndpoint,
      factoryAddress,
    });

    const { message } = await client.getSignatureFormat(eoaAddress);
    const signature = await generateSignature(message, walletPrivateKey);
    const res = await client.authWithSignature({
      message: message,
      signature: signature,
    });

    client.setAuthKey(res.authKey);
  });

  describe("Timeout Configuration", () => {
    test("should use default timeout configuration when not specified", () => {
      const defaultClient = new Client({ endpoint: avsEndpoint });
      const config = defaultClient.getTimeoutConfig();

      expect(config.timeout).toBe(30000); // 30 seconds
      expect(config.retries).toBe(3);
      expect(config.retryDelay).toBe(1000); // 1 second
    });

    test("should use custom timeout configuration when specified", () => {
      const customClient = new Client({
        endpoint: avsEndpoint,
        timeout: {
          timeout: 5000,
          retries: 2,
          retryDelay: 500,
        },
      });

      const config = customClient.getTimeoutConfig();
      expect(config.timeout).toBe(5000);
      expect(config.retries).toBe(2);
      expect(config.retryDelay).toBe(500);
    });

    test("should allow updating timeout configuration after creation", () => {
      const newConfig = {
        timeout: 15000,
        retries: 1,
        retryDelay: 750,
      };

      client.setTimeoutConfig(newConfig);
      const config = client.getTimeoutConfig();

      expect(config.timeout).toBe(15000);
      expect(config.retries).toBe(1);
      expect(config.retryDelay).toBe(750);
    });

    test("should merge partial timeout configurations", () => {
      // Set initial config
      client.setTimeoutConfig({ timeout: 10000, retries: 2, retryDelay: 500 });

      // Update only timeout
      client.setTimeoutConfig({ timeout: 20000 });

      const config = client.getTimeoutConfig();
      expect(config.timeout).toBe(20000); // Updated
      expect(config.retries).toBe(2); // Preserved
      expect(config.retryDelay).toBe(500); // Preserved
    });
  });

  describe("Timeout Presets", () => {
    test("should have correct timeout preset values", () => {
      expect(TimeoutPresets.FAST).toEqual({
        timeout: 5000,
        retries: 2,
        retryDelay: 500,
      });

      expect(TimeoutPresets.NORMAL).toEqual({
        timeout: 30000,
        retries: 3,
        retryDelay: 1000,
      });

      expect(TimeoutPresets.SLOW).toEqual({
        timeout: 120000,
        retries: 2,
        retryDelay: 2000,
      });

      expect(TimeoutPresets.NO_RETRY).toEqual({
        timeout: 30000,
        retries: 0,
        retryDelay: 0,
      });
    });

    test("should work with preset timeout configurations", () => {
      const fastClient = new Client({
        endpoint: avsEndpoint,
        timeout: TimeoutPresets.FAST,
      });

      const config = fastClient.getTimeoutConfig();
      expect(config).toEqual(TimeoutPresets.FAST);
    });
  });

  describe("Integration with Real Requests", () => {
    test("should successfully execute getWallets with custom timeout", async () => {
      // Reset to default config first
      client.setTimeoutConfig({
        timeout: 30000,
        retries: 3,
        retryDelay: 1000,
      });

      // This should work normally
      const wallets = await client.getWallets({
        timeout: TimeoutPresets.NORMAL,
      });

      expect(Array.isArray(wallets)).toBe(true);
    });

    test("should successfully execute getSignatureFormat with FAST preset", async () => {
      const result = await client.getSignatureFormat(eoaAddress);

      expect(result).toBeDefined();
      expect(result.message).toBeDefined();
      expect(typeof result.message).toBe("string");
    });

    test("should handle runNodeWithInputs with custom timeout (if server responds quickly)", async () => {
      // Use a simple customCode node that should execute quickly
      const result = await client.runNodeWithInputs(
        {
          nodeType: "customCode",
          nodeConfig: {
            source: "return { value: 42, timestamp: Date.now() };",
            lang: 0,
          },
          inputVariables: {},
        },
        {
          timeout: TimeoutPresets.FAST, // 5 second timeout
        }
      );

      expect(result).toBeDefined();
      expect(typeof result.success).toBe("boolean");

      // If the request succeeds, verify the structure
      if (result.success) {
        expect(result.data).toBeDefined();
        expect(result.nodeId).toBeDefined();
      } else {
        // If it fails, at least verify we got an error message
        expect(result.error).toBeDefined();
        console.log("Custom code execution failed:", result.error);
      }
    });
  });

  describe("Timeout Configuration Client Lifecycle", () => {
    test("should allow chaining timeout configurations", () => {
      const testClient = new Client({
        endpoint: avsEndpoint,
        timeout: { timeout: 5000 },
      });

      testClient.setTimeoutConfig({ retries: 5 });
      testClient.setTimeoutConfig({ retryDelay: 200 });

      const config = testClient.getTimeoutConfig();
      expect(config.timeout).toBe(5000);
      expect(config.retries).toBe(5);
      expect(config.retryDelay).toBe(200);
    });

    test("should create independent client configurations", () => {
      const client1 = new Client({
        endpoint: avsEndpoint,
        timeout: TimeoutPresets.FAST,
      });

      const client2 = new Client({
        endpoint: avsEndpoint,
        timeout: TimeoutPresets.SLOW,
      });

      expect(client1.getTimeoutConfig()).toEqual(TimeoutPresets.FAST);
      expect(client2.getTimeoutConfig()).toEqual(TimeoutPresets.SLOW);

      // Modifying one shouldn't affect the other
      client1.setTimeoutConfig({ timeout: 1000 });
      expect(client1.getTimeoutConfig().timeout).toBe(1000);
      expect(client2.getTimeoutConfig()).toEqual(TimeoutPresets.SLOW);
    });
  });
});