import { Client } from "@avaprotocol/sdk-js";
import { TimeoutPresets, type TimeoutConfig } from "@avaprotocol/types";

// Mock the gRPC client for timeout testing
jest.mock("@/grpc_codegen/avs_grpc_pb", () => ({
  AggregatorClient: jest.fn().mockImplementation(() => ({
    getKey: jest.fn(),
    listTasks: jest.fn(),
    runNodeWithInputs: jest.fn(),
    getWallet: jest.fn(),
  })),
}));

describe("SDK Timeout Functionality", () => {
  let sdk: Client;
  let mockClient: any;

  beforeEach(() => {
    // Create SDK instance with custom timeout configuration
    sdk = new Client({
      endpoint: "localhost:2206",
      timeout: {
        timeout: 5000,
        retries: 2,
        retryDelay: 100,
      },
    });

    // Get reference to the mocked client
    mockClient = (sdk as any).rpcClient;
  });

  afterEach(() => {
    jest.clearAllMocks();
    jest.useRealTimers();
  });

  describe("Timeout Configuration", () => {
    it("should use default timeout configuration when not specified", () => {
      const defaultSDK = new Client({ endpoint: "localhost:2206" });
      const config = defaultSDK.getTimeoutConfig();

      expect(config.timeout).toBe(30000);
      expect(config.retries).toBe(3);
      expect(config.retryDelay).toBe(1000);
    });

    it("should use custom timeout configuration when specified", () => {
      const config = sdk.getTimeoutConfig();

      expect(config.timeout).toBe(5000);
      expect(config.retries).toBe(2);
      expect(config.retryDelay).toBe(100);
    });

    it("should allow updating timeout configuration", () => {
      const newConfig: TimeoutConfig = {
        timeout: 15000,
        retries: 1,
        retryDelay: 500,
      };

      sdk.setTimeoutConfig(newConfig);
      const config = sdk.getTimeoutConfig();

      expect(config.timeout).toBe(15000);
      expect(config.retries).toBe(1);
      expect(config.retryDelay).toBe(500);
    });
  });

  describe("Basic Timeout Functionality", () => {
    it("should execute successful request within timeout", async () => {
      const mockResponse = { getKey: () => "test-auth-key" };

      mockClient.getKey.mockImplementation((req: any, meta: any, callback: any) => {
        setTimeout(() => callback(null, mockResponse), 100);
      });

      const result = await sdk.authWithSignature({
        message: "test-message",
        signature: "test-signature",
      });

      expect(result.authKey).toBe("test-auth-key");
      expect(mockClient.getKey).toHaveBeenCalledTimes(1);
    });

    it("should timeout after specified duration", async () => {
      jest.useFakeTimers();

      mockClient.getKey.mockImplementation((req: any, meta: any, callback: any) => {
        // Never call callback to simulate hanging request
      });

      const promise = sdk.authWithSignature(
        {
          message: "test-message",
          signature: "test-signature",
        },
        {
          timeout: { timeout: 1000, retries: 0 },
        }
      );

      // Fast-forward time to trigger timeout
      jest.advanceTimersByTime(1001);

      await expect(promise).rejects.toMatchObject({
        message: expect.stringContaining("gRPC request timeout after 1000ms"),
        isTimeout: true,
        attemptsMade: 1,
        methodName: "getKey",
      });
    });

    it("should retry on timeout errors", async () => {
      jest.useFakeTimers();

      let callCount = 0;
      mockClient.listTasks.mockImplementation((req: any, meta: any, callback: any) => {
        callCount++;
        // Never respond to always timeout
      });

      const promise = sdk.getWorkflows(["0x123"], {
        timeout: { timeout: 500, retries: 2, retryDelay: 100 },
      });

      // First timeout
      jest.advanceTimersByTime(501);
      // Retry delay
      jest.advanceTimersByTime(100);
      // Second timeout
      jest.advanceTimersByTime(501);

      await expect(promise).rejects.toMatchObject({
        isTimeout: true,
        attemptsMade: 2,
      });

      expect(callCount).toBe(2);
    });

    it("should retry on UNAVAILABLE status", async () => {
      let callCount = 0;
      const unavailableError = {
        code: 14, // status.UNAVAILABLE
        message: "Service unavailable",
      };

      mockClient.getKey.mockImplementation((req: any, meta: any, callback: any) => {
        callCount++;
        if (callCount === 1) {
          callback(unavailableError);
        } else {
          callback(null, { getKey: () => "test-key" });
        }
      });

      const result = await sdk.authWithSignature(
        {
          message: "test-message",
          signature: "test-signature",
        },
        {
          timeout: { timeout: 5000, retries: 2, retryDelay: 50 },
        }
      );

      expect(result.authKey).toBe("test-key");
      expect(callCount).toBe(2);
    });

    it("should not retry non-retryable errors", async () => {
      let callCount = 0;
      const authError = {
        code: 16, // status.UNAUTHENTICATED
        message: "Authentication failed",
      };

      mockClient.getKey.mockImplementation((req: any, meta: any, callback: any) => {
        callCount++;
        callback(authError);
      });

      await expect(
        sdk.authWithSignature(
          {
            message: "test-message",
            signature: "test-signature",
          },
          {
            timeout: { timeout: 5000, retries: 3 },
          }
        )
      ).rejects.toEqual(authError);

      expect(callCount).toBe(1);
    });
  });

  describe("Timeout Presets", () => {
    it("should work with FAST preset", async () => {
      const mockResponse = { getItems: () => [], getPageInfo: () => ({ getStartCursor: () => "", getEndCursor: () => "", getHasPreviousPage: () => false, getHasNextPage: () => false }) };

      mockClient.listTasks.mockImplementation((req: any, meta: any, callback: any) => {
        setTimeout(() => callback(null, mockResponse), 100);
      });

      // Using FAST preset through options
      const result = await sdk.getWorkflows(["0x123"], {
        timeout: TimeoutPresets.FAST,
      });

      expect(result.items).toEqual([]);
    });

    it("should timeout quickly with FAST preset", async () => {
      jest.useFakeTimers();

      mockClient.listTasks.mockImplementation((req: any, meta: any, callback: any) => {
        // Never respond
      });

      const promise = sdk.getWorkflows(["0x123"], {
        timeout: TimeoutPresets.FAST,
      });

      jest.advanceTimersByTime(5001);

      await expect(promise).rejects.toMatchObject({
        message: expect.stringContaining("timeout after 5000ms"),
        isTimeout: true,
      });
    });

    it("should not retry with NO_RETRY preset", async () => {
      let callCount = 0;
      const timeoutError = {
        code: 4, // status.DEADLINE_EXCEEDED
        message: "Deadline exceeded",
      };

      mockClient.listTasks.mockImplementation((req: any, meta: any, callback: any) => {
        callCount++;
        callback(timeoutError);
      });

      await expect(
        sdk.getWorkflows(["0x123"], {
          timeout: TimeoutPresets.NO_RETRY,
        })
      ).rejects.toEqual(timeoutError);

      expect(callCount).toBe(1);
    });
  });

  describe("RunNodeWithInputs Specific Tests", () => {
    it("should handle blockTrigger node with fast timeout", async () => {
      const mockResponse = {
        getSuccess: () => true,
        getData: () => ({ currentBlock: 12345 }),
      };

      mockClient.runNodeWithInputs.mockImplementation((req: any, meta: any, callback: any) => {
        // Validate request structure
        expect(req.getNodeType()).toBe("blockTrigger");
        setTimeout(() => callback(null, mockResponse), 100);
      });

      const result = await sdk.runNodeWithInputs(
        {
          nodeType: "blockTrigger",
          nodeConfig: {
            interval: 5,
          },
          inputVariables: {
            currentBlock: 12345,
          },
        },
        {
          timeout: TimeoutPresets.FAST,
        }
      );

      expect(result.success).toBe(true);
    });

    it("should handle customCode node with custom timeout", async () => {
      const mockResponse = {
        getSuccess: () => true,
        getData: () => ({ value: 42 }),
      };

      mockClient.runNodeWithInputs.mockImplementation((req: any, meta: any, callback: any) => {
        expect(req.getNodeType()).toBe("customCode");
        setTimeout(() => callback(null, mockResponse), 100);
      });

      const result = await sdk.runNodeWithInputs(
        {
          nodeType: "customCode",
          nodeConfig: {
            lang: 0,
            source: "42",
          },
          inputVariables: {
            testVar: "hello world",
          },
        },
        {
          timeout: {
            timeout: 15000,
            retries: 1,
            retryDelay: 500,
          },
        }
      );

      expect(result.success).toBe(true);
    });

    it("should handle node execution failures gracefully", async () => {
      const mockResponse = {
        getSuccess: () => false,
        getError: () => "Node execution failed: Invalid syntax",
      };

      mockClient.runNodeWithInputs.mockImplementation((req: any, meta: any, callback: any) => {
        callback(null, mockResponse);
      });

      const result = await sdk.runNodeWithInputs(
        {
          nodeType: "customCode",
          nodeConfig: {
            lang: 0,
            source: "invalid syntax here",
          },
        },
        {
          timeout: TimeoutPresets.FAST,
        }
      );

      expect(result.success).toBe(false);
      expect(result.error).toContain("Node execution failed");
    });
  });

  describe("Error Context", () => {
    it("should add timeout context to timeout errors", async () => {
      jest.useFakeTimers();

      mockClient.getKey.mockImplementation((req: any, meta: any, callback: any) => {
        // Never respond
      });

      const promise = sdk.authWithSignature(
        {
          message: "test-message",
          signature: "test-signature",
        },
        {
          timeout: {
            timeout: 2000,
            retries: 1,
            retryDelay: 300,
          },
        }
      );

      // First timeout
      jest.advanceTimersByTime(2001);
      // Retry delay
      jest.advanceTimersByTime(300);
      // Second timeout
      jest.advanceTimersByTime(2001);

      await expect(promise).rejects.toMatchObject({
        isTimeout: true,
        attemptsMade: 1,
        methodName: "getKey",
        message: expect.stringContaining("timeout after 2000ms"),
      });
    });

    it("should not add timeout context to non-timeout errors", async () => {
      const networkError = new Error("Network connection failed");

      mockClient.listTasks.mockImplementation((req: any, meta: any, callback: any) => {
        callback(networkError);
      });

      await expect(
        sdk.getWorkflows(["0x123"], {
          timeout: TimeoutPresets.NORMAL,
        })
      ).rejects.toEqual(networkError);
    });
  });

  describe("Client Lifecycle", () => {
    it("should allow setting timeout config after client creation", () => {
      const newConfig: TimeoutConfig = {
        timeout: 20000,
        retries: 4,
        retryDelay: 2000,
      };

      sdk.setTimeoutConfig(newConfig);
      const retrievedConfig = sdk.getTimeoutConfig();

      expect(retrievedConfig).toEqual({
        timeout: 20000,
        retries: 4,
        retryDelay: 2000,
      });
    });

    it("should merge partial timeout configs", () => {
      // Start with custom config
      sdk.setTimeoutConfig({ timeout: 10000 });

      // Update only retries
      sdk.setTimeoutConfig({ retries: 5 });

      const config = sdk.getTimeoutConfig();
      expect(config.timeout).toBe(10000); // Should remain
      expect(config.retries).toBe(5); // Should be updated
      expect(config.retryDelay).toBe(100); // Should remain from initial config
    });
  });
});